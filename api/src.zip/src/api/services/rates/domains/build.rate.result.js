
import { fixedToN } from '../../../../lib/utils/rate.utils.js';

import { 
    getScope, 
    SCOPE_LABELS 
} from '../../../../lib/constants/scopes.zone.js';

const scope = getScope(process.env.DEFAULT_COUNTRY);

export function buildRateComplete({
    agency,
    zone = SCOPE_LABELS[scope],
    services = []
}) {
    
    const available = services.some(service =>
        service.incidents?.length === 0
    );

    return {
        agency,
        available,
        zone,
        services
    }
};

export function buildRateResult({
    service,
    transportType,
    itemCount = 0,
    totalWeight = 0,
    concepts = [],
    incidents = [],
}) {

    return {
        service,
        transportType,
        itemCount,
        totalWeight,
        concepts,
        incidents,
        total: fixedToN(
            concepts.reduce(
                (sum, item) => sum + item.amount,
                0
            )
        )
    };
}

export function buildIncident(code, meta = {}) {
    return {
        code,
        meta
    };
}

export function buildConcept(code, amount, meta = {}) {
    return {
        code,
        amount: fixedToN(amount),
        meta
    };
}

export function buildParcelRate({
    serviceName,
    totalWeight,
    itemCount,
    concepts = [],
    incidents = []
}) {

    return buildRateResult({
        service: serviceName,
        transportType: 'parcel',
        itemCount,
        totalWeight,
        concepts,
        incidents
    });
}

export function buildApiErrorResult({
    agency,
    transportType = 'unknown',
    error,
    presentRate
}) {
    return buildRateComplete({
        agency,

        services: presentRate([
            buildRateResult({
                service: 'API_ERROR',
                transportType,

                incidents: [
                    buildIncident(
                        'API_ERROR',
                        {
                            code: error?.status,
                            message: error?.message
                        }
                    )
                ]
            })
        ])
    });
}

export function buildStaticErrorResult({
    presentRate,
    agency,
    zone = SCOPE_LABELS[scope],
    transportType = 'unknown',
    code,
    message = ''
}) {
    return buildRateComplete({
        agency,
        zone,

        services: presentRate([
            buildRateResult({
                service: code,
                transportType,

                incidents: [
                    buildIncident(
                        code,
                        {
                            message
                        }
                    )
                ]
            })
        ])
    });
}

export function buildRejectedServices(
    rejected, 
    transportType = 'pallet'
) {
    if (!rejected.length) return [];

    return [
        buildRateResult({
            service: 'REJECTED_PALLET',
            transportType,
            incidents: rejected.map(item => (
                buildIncident(
                    'PALLET_DIMENSION_REJECTED', 
                    item
                )
            ))
        })
    ];
}