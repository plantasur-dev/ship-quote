
import createHttpError from "http-errors";

import Agency from "../../lib/models/agency.model.js";

import Zone from "../../lib/models/zone.model.js";
import ZoneRules from "../../lib/models/zone.rules.model.js";

export const create = async (req, res) => {

    const { 
        agencyId, 
        name, 
        provinces, 
        calculationMode,
        volumetric,
        pricingMode,
        postalCodeRanges 
    } = req.body;

    const agencyExists = await Agency.exists({ _id: agencyId });

    if (!agencyExists) throw createHttpError(404, `Agency ${ agencyId } not found`); 

    const zone = await Zone.create({
        agencyId, 
        name, 
        provinces, 
        calculationMode,
        volumetric,
        pricingMode,
    });
    
    const zoneRulesProvinces = provinces.map(province => ({
        zoneId: zone.id,
        agencyId,
        province,
        postalCodeRanges
    }));
    
    const zoneRule = await ZoneRules.insertMany(zoneRulesProvinces);
    
    res.status(201).json(zone);
};

export const list = async (req, res) => {

    const zones = await Zone
        .find()
        .populate('agencyId', 'name code');

    if (!zones.length) throw createHttpError(404, 'Zones not found');

    res.json(zones);
};

export const details = async (req, res) => {

    const zone = await Zone
        .findById(req.params.zoneId)
        .populate('agencyId', 'name code');

    if (!zone) throw createHttpError(404, 'Zone not found');

    res.json(zone);
};